import React from 'react';
import AddUser from './AddUser';

function App() {
  return (
    <div>
      <h1>Stock Dashboard</h1>
      <AddUser />
    </div>
  );
}

export default App;
